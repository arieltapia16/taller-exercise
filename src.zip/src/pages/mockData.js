// Transaction ID, Date, Description, Amount (in USD)


const paymentsData = [
  
  {
    id: 1,
    date: 1696875644,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 2,
    date: 1696789244,
    description: 'Food bill',
    amount: 35.8
  },
  {
    id: 3,
    date: 1696702844,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 4,
    date: 1701973244,
    description: 'expenses bill',
    amount: 35.8
  },
  {
    id: 5,
    date: 1691432444,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 6,
    date: 1691259644,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 7,
    date: 1691346044,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 8,
    date: 1696875644,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 9,
    date: 1701973244,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 10,
    date: 1696875644,
    description: 'Power bill',
    amount: 35.8
  },
  {
    id: 11,
    date: 1701973244,
    description: 'Power bill',
    amount: 35.8
  },
]

export default paymentsData